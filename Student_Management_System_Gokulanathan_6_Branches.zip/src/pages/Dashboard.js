export const Dashboard = () => 'Dashboard';
